To run all tests use 
``npm test``
To run  specific tag use
``npm run test-tag -t "{tag}"``