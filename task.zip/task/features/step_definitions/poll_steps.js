const { Given, When, AfterAll, Then } = require("cucumber");
const { buildDriver, waitForElement, scrollToElement } = require("../utils/config");
const { By } = require("selenium-webdriver");
const assert = require('assert')

const driver = buildDriver()

AfterAll('end', async function () {
    await driver.quit()
});


const openNextQuestion = async function () {
    const nextButtonLocator = By.className("nw-survey-filing-next-link")
    await waitForElement(driver, nextButtonLocator)
    const nextButton = await driver.findElement(nextButtonLocator)
    await nextButton.click()
}

// Scrolls to object and clicks to guarantee its visablitity
const clickPageObject = async function (element) {
    await scrollToElement(driver, element)
    await element.click()
}


Given("I open poll with id {string}", async function (string) {
    const url = "https://edurio.com/poll/" + string
    await driver.manage().window().maximize()
    await driver.get(url);
});

Given("I accept cookies", async function () {
    await waitForElement(driver, By.css(`p a[href^="https"]`))
    const acceptCookies = await driver.findElement(By.className("accept-btn"))
    await acceptCookies.click()
})

When('I start the poll', async function () {
    await waitForElement(driver, By.className("poll-start-survey"))
    const startSurvey = await driver.findElement(By.className("poll-start-survey"))
    await clickPageObject(startSurvey)
});

When('I select option {string}', async function (option) {
    await waitForElement(driver, By.className("poll-question"))
    // Select option
    const answer = await driver.findElement(By.xpath(`//span/span[contains(text(),"${option}")]`))
    await clickPageObject(answer)
});

When('I select option {string} and continue', async function (option) {
    await waitForElement(driver, By.className("poll-question"))
    // Select option
    const answer = await driver.findElement(By.xpath(`//span/span[contains(text(),"${option}")]`))
    await clickPageObject(answer)
    // Continue
    await openNextQuestion()
});

When('I select option {string}, I further explain that {string} and continue', async function (option, explanation) {
    // Select option
    const optionLocator = By.xpath(`//span/span[contains(text(),"${option}")]`)
    await waitForElement(driver, optionLocator)
    const optionElement = await driver.findElement(optionLocator)
    await clickPageObject(optionElement)
    // Explain answer
    const inactiveTextAreaText = await driver.findElement(By.xpath("//span[contains(text(),'answer')]"))
    await clickPageObject(inactiveTextAreaText)
    const textArea = await driver.findElement(By.css("textarea.comment-textarea-nr-0"))
    textArea.sendKeys(explanation)
    // Continue
    await openNextQuestion()
});

When('I select {string} and {string} and continue', async function (option1, option2) {
    await waitForElement(driver, By.xpath(`//span/span[contains(text(),"${option1}")]`))
    // Select options
    const answer1 = await driver.findElement(By.xpath(`//span/span[contains(text(),"${option1}")]`))
    await clickPageObject(answer1)
    const answer2 = await driver.findElement(By.xpath(`//span/span[contains(text(),"${option2}")]`))
    await clickPageObject(answer2)
    // Continue
    await openNextQuestion()
});

When('I select {string} for question 1 and {string} for question 2 and continue', async function (option1, option2) {
    // This checkes all_radios_n value which is different for each question
    answer1Locator = By.xpath(`//label[input[@name="all_radios_1"]]/span/span[text()="${option1}"]`)
    answer2Locator = By.xpath(`//label[input[@name="all_radios_2"]]/span/span[text()="${option2}"]`)
    // Click 1st answer
    await waitForElement(driver, answer1Locator)
    const answer1 = await driver.findElement(answer1Locator)
    await clickPageObject(answer1)
    // Click 2nd answer
    const answer2 = await driver.findElement(answer2Locator)
    await clickPageObject(answer2)
    // Continue
    await openNextQuestion()
});

When('I enter {string} and finish survey', async function (text) {
    await waitForElement(driver, By.css("div.answer-type-open-answer textarea[placeholder]"))
    await driver.sleep(1000)
    // Enter answer in text area
    textAreaLocator = By.css("textarea")
    await waitForElement(driver, textAreaLocator)
    const textArea = await driver.findElement(textAreaLocator)
    await textArea.sendKeys(text)
    // Finish survey
    await openNextQuestion()
})

Then('I confirm to end the survey', async function () {
    await waitForElement(driver, By.className("modal-default-button"))
    const confirmButton = await driver.findElement(By.className("modal-default-button"))
    clickPageObject(confirmButton)
})

Then('I wait for {int} seconds', async function (time) {
    const waitTime = time * 1000
    await driver.sleep(waitTime)
});

Then('I confirm the survey is ended', async function () {
    await waitForElement(driver, By.className("nw-poll-finished"))
    const pollFinished = await driver.findElement(By.className("nw-poll-finished"))
    assert.ok(await pollFinished.isDisplayed())

    const returnHomeButton = await driver.findElement(By.css(`a.btn.btn-primary[href^="/users"]`))
    assert.equal("Return home", await returnHomeButton.getText())
})