const { setDefaultTimeout } = require('cucumber');
const { Builder, until } = require('selenium-webdriver');

module.exports = {
    buildDriver: function () {
        const timeoutSeconds = 10
        setDefaultTimeout(timeoutSeconds * 1000)
        return new Builder().forBrowser('chrome').build()
    },
    waitForElement: async (driver, locator) => {
        const defaultWaitTime = 5000 // 5 seconds
        await driver.wait(
            until.elementLocated(locator),
            defaultWaitTime,
            `Element with locator ${locator} not found after ${defaultWaitTime / 1000} seconds` // Error message
        )
    },
    scrollToElement: async (driver, element) => {
        await driver.executeScript(`arguments[0].scrollIntoView({block: "center", behavior: "smooth"})`, element)
        await driver.sleep(500)
    }
}